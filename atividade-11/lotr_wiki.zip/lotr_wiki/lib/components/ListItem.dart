import 'package:flutter/material.dart';

import '../models/page_arguments.dart';

class ListItem extends StatelessWidget {
  final String detailScreenRouteName;
  final String entityId;
  final String entityName;

  const ListItem({Key? key, required this.detailScreenRouteName, required this.entityId, required this.entityName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextButton(
        onPressed: () {
          if (detailScreenRouteName.isNotEmpty) {
            Navigator.pushNamed(
                context,
                detailScreenRouteName,
                arguments: PageArguments(entityId)
            );
          }
        } ,
        child: Card(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              trailing: detailScreenRouteName.isNotEmpty ?  const Icon(Icons.keyboard_arrow_right, color: Colors.white, size: 30.0) : null,
              title: Text(
                entityName,
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20
                ),
              ),
              tileColor: Colors.grey[800],
              textColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)
              ),
            )
        )
    );
  }
}
