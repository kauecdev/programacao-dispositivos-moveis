import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CardItem extends StatelessWidget {

  final String text;
  final IconData icon;
  final VoidCallback onPressed;

  const CardItem({Key? key, required this.text, required this.icon, required this.onPressed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(10),
      child: SizedBox(
        width: 140,
        height: 140,
        child: TextButton(
            style: TextButton.styleFrom(
              primary: Colors.white,
              backgroundColor: const Color(0xFF514947),
            ),
            onPressed: onPressed,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    icon,
                    size: 50,
                  ),
                  Text(
                    text,
                    style: const TextStyle(
                      fontSize: 20,
                    ),
                  ),
                ]
            )
        ),
      ),
    );
  }
}
