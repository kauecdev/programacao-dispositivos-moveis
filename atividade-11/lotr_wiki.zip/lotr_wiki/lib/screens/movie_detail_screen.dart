import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lotr_wiki/models/character.dart';
import 'package:http/http.dart' as http;
import 'package:lotr_wiki/models/movie.dart';
import 'package:url_launcher/url_launcher.dart';

class MovieDetailScreen extends StatefulWidget {

  static const routeName = '/movie';

  final String movieId;

  const MovieDetailScreen({Key? key, required this.movieId}) : super(key: key);

  @override
  State<MovieDetailScreen> createState() => _MovieDetailScreen();

}

class _MovieDetailScreen extends State<MovieDetailScreen> {

  AssetImage backgroundImage = const AssetImage('assets/grey_background.jpg');

  Future<http.Response> getMovie() async {
    String? token = dotenv.env['TOKEN'];

    final response = await http
        .get(
        Uri.parse('https://the-one-api.dev/v2/movie/${widget.movieId}'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        });

    final responseDecode = jsonDecode(response.body);

    Movie movie = Movie.fromJson(responseDecode["docs"][0]);

    setState(() {
      backgroundImage = AssetImage(movie.movieImage);
    });

    return response;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          iconTheme: const IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: double.infinity,
                height: 300,
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: backgroundImage,
                      fit: BoxFit.cover
                  ),
                ),
              ),
              FutureBuilder<http.Response>(
                  future: getMovie(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      Movie movieLoaded = Movie.fromJson(jsonDecode(snapshot.data!.body)['docs'][0]);
                      return Container(
                        padding: EdgeInsets.all(16),
                        child: Padding(
                            padding: EdgeInsets.all(16),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  movieLoaded.name,
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 40,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                buildTextInfo("Duração em minutos", movieLoaded.runtimeInMinutes),
                                buildTextInfo("Orçamento em milhões (U\$)", movieLoaded.budgetInMillions),
                                buildTextInfo("Rotten Tomatoes Score", movieLoaded.rottenTomatoesScore),
                              ],
                            )
                        ),
                      );
                    }
                    return const Center(
                        child: CircularProgressIndicator()
                    );
                  }
              )
            ]
        )
    );
    //       )
    //   );
    // }
  }
}

Row buildTextInfo(String title, dynamic text) {
  return Row(
    children: <Widget>[
      Text(
        '${title}: ',
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      Text(
        '$text',
        style: const TextStyle(
          fontSize: 18,
        )
      ),
    ],
  );
}