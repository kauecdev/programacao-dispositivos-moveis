import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:lotr_wiki/components/ListItem.dart';
import 'package:lotr_wiki/models/character.dart';
import 'package:http/http.dart' as http;
import 'package:lotr_wiki/models/movie.dart';
import 'package:lotr_wiki/models/page_arguments.dart';
import 'package:lotr_wiki/screens/character_detail_screen.dart';
import 'package:lotr_wiki/screens/movie_detail_screen.dart';

class MovieListScreen extends StatefulWidget {
  const MovieListScreen({Key? key}) : super(key: key);

  @override
  State<MovieListScreen> createState() => _MovieListScreenState();
}

class _MovieListScreenState extends State<MovieListScreen> {

  late List<Movie> movieList = [];

  Future<void> getMovies() async {
    String? token = dotenv.env['TOKEN'];

    final response = await http
        .get(
        Uri.parse('https://the-one-api.dev/v2/movie'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        });

    if (response.statusCode != 200) {
      throw Exception('Failed to load movies');
    }

    final responseDecoded = jsonDecode(response.body);

    List movieListJson = responseDecoded['docs'] as List;

    List<Movie> moviesLoaded = movieListJson.where((movieJson) => !movieJson["name"].contains("Series"))
        .map((movieJson) => Movie.fromJson(movieJson)).toList();

    setState(() {
      movieList = moviesLoaded;
    });
  }

  @override
  void initState() {
    getMovies();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
        ),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/movie_screen_background.jpg'),
              fit: BoxFit.cover
          ),
        ),
        child: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                if (movieList.isNotEmpty) {
                  return ListView.separated(
                    itemBuilder: (BuildContext context, int index) {
                      Movie movie = movieList[index];
                      return ListItem(
                          detailScreenRouteName: MovieDetailScreen.routeName,
                          entityId: movie.id,
                          entityName: movie.name,
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return const Divider(height: 1);
                    },
                    itemCount: movieList.length
                  );
                } else {
                  return const Center(
                      child: CircularProgressIndicator()
                  );
                }
              }),
            )
        ),
    );
  }
}
