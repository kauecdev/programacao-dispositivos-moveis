import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lotr_wiki/models/character.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class CharacterDetailScreen extends StatefulWidget {

  static const routeName = '/character';

  final String characterId;

  const CharacterDetailScreen({Key? key, required this.characterId}) : super(key: key);

  @override
  State<CharacterDetailScreen> createState() => _CharacterDetailScreen();

}

class _CharacterDetailScreen extends State<CharacterDetailScreen> {

  AssetImage backgroundImage = const AssetImage('assets/grey_background.jpg');
  late Character character;

  void _launchURL(String url) async {
    if (!await launchUrl(Uri.parse(url))) throw 'Could not launch $url';
  }

  void getBackgroundImage(String race) {
    String backgroundImagePath = "";

    switch (race) {
      case "Men":
      case "Human":
      case "Humans":
        backgroundImagePath = 'assets/humans.jpg';
        break;
      case "Dwarf":
      case "Dwarves":
        backgroundImagePath = 'assets/dwarves.jpg';
        break;
      case "Ainur":
        backgroundImagePath = 'assets/ainur.jpg';
        break;
      case "Balrog":
        backgroundImagePath = 'assets/balrog.jpg';
        break;
      case "Orc":
      case "Orcs":
      case "Goblin":
      case "Uruk-hai":
      case "Black Uruk":
        backgroundImagePath = 'assets/orcs.jpg';
        break;
      case "Hobbit":
      case "Hobbits":
        backgroundImagePath = 'assets/hobbits.jpg';
        break;
      case "Elf":
      case "Elves":
        backgroundImagePath = 'assets/elves.jpg';
        break;
      case "Dragon":
      case "Dragons":
        backgroundImagePath = 'assets/dragons.jpg';
        break;
      case "Maiar":
        backgroundImagePath = 'assets/maiar.jpg';
        break;
      default: 'assets/grey_background.jpg';
    }

    setState(() {
      backgroundImage = AssetImage(backgroundImagePath);
    });
  }

  Future<http.Response> getCharacter() async {
    String? token = dotenv.env['TOKEN'];

    final response = await http
        .get(
        Uri.parse('https://the-one-api.dev/v2/character/${widget.characterId}'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        });

    final responseDecode = jsonDecode(response.body);

    final characterRace = responseDecode["docs"][0]["race"];

    getBackgroundImage(characterRace);

    return response;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          iconTheme: const IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: double.infinity,
                height: 300,
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: backgroundImage,
                      fit: BoxFit.cover
                  ),
                ),
              ),
              FutureBuilder<http.Response>(
                  future: getCharacter(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      Character characterLoaded = Character.fromJson(jsonDecode(snapshot.data!.body)['docs'][0]);
                      return Container(
                        padding: EdgeInsets.all(16),
                        child: Padding(
                            padding: EdgeInsets.all(16),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  characterLoaded.name,
                                  style: TextStyle(
                                    color: Colors.grey[800],
                                    fontSize: 40,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                buildTextInfo("Raça", characterLoaded.race),
                                buildTextInfo("Gênero", characterLoaded.gender),
                                buildTextInfo("Reino", characterLoaded.realm),
                                buildTextInfo("Nascimento", characterLoaded.birth),
                                buildTextInfo("Morte", characterLoaded.death),
                                const SizedBox(height: 100),
                                Align(
                                  alignment: FractionalOffset.bottomCenter,
                                  child: TextButton(
                                      style: TextButton.styleFrom(
                                        padding: const EdgeInsets.all(10),
                                        backgroundColor: Colors.grey[800],
                                      ),
                                      onPressed: () {
                                        _launchURL(characterLoaded.wikiUrl);
                                      },
                                      child: const Text(
                                        "Link to Wiki Page",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                        ),
                                      )
                                  ),
                                )
                              ],
                            )
                        ),
                      );
                    }
                    return const Center(
                        child: CircularProgressIndicator()
                    );
                  }
              )
            ]
        )
    );
  }
}

Row buildTextInfo(String title, String text) {
  return Row(
    children: <Widget>[
      Text(
        '${title}: ',
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      Text(
        text,
        style: const TextStyle(
          fontSize: 18,
        )
      ),
    ],
  );
}