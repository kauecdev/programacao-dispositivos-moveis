import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:lotr_wiki/components/ListItem.dart';
import 'package:lotr_wiki/models/character.dart';
import 'package:http/http.dart' as http;
import 'package:lotr_wiki/screens/character_detail_screen.dart';

class CharacterListScreen extends StatefulWidget {
  const CharacterListScreen({Key? key}) : super(key: key);

  @override
  State<CharacterListScreen> createState() => _CharacterListScreenState();
}

class _CharacterListScreenState extends State<CharacterListScreen> {

  late List<Character> characterList = [];

  final PagingController<int, Character> _pagingController = PagingController(firstPageKey: 1);

  Future<void> getCharacters(int pageKey) async {
    try {
      String? token = dotenv.env['TOKEN'];

      final response = await http
          .get(
          Uri.parse('https://the-one-api.dev/v2/character?limit=10&page=$pageKey'),
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer $token'
          });

      if (response.statusCode != 200) {
        throw Exception('Failed to load characters');
      }

      final responseDecoded = jsonDecode(response.body);

      List characterListJson = responseDecoded['docs'] as List;

      List<Character> charactersLoaded = characterListJson.map((characterJson) => Character.fromJson(characterJson)).toList();

      final isLastPage = pageKey == responseDecoded["pages"];

      if (isLastPage) {
        _pagingController.appendLastPage(charactersLoaded);
      } else {
        final nextPageKey = pageKey + 1;
        _pagingController.appendPage(charactersLoaded, nextPageKey);
      }
    } catch (error) {
      _pagingController.error = error;
    }
  }

  @override
  void initState() {
    _pagingController.addPageRequestListener((pageKey) {
      getCharacters(pageKey);
    });
    super.initState();
  }

  @override
  void dispose() {
    _pagingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          iconTheme: IconThemeData(
            color: Colors.grey[800],
          ),
        ),
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/character_screen_background.png'),
              fit: BoxFit.cover
            ),
          ),
          child: SafeArea(
              child: RefreshIndicator(
                onRefresh: () => Future.sync(
                      () => _pagingController.refresh(),
                ),
                child: PagedListView(
                  pagingController: _pagingController,
                  builderDelegate: PagedChildBuilderDelegate<Character>(
                    itemBuilder: (context, character, index) {
                      return ListItem(
                          detailScreenRouteName: CharacterDetailScreen.routeName,
                          entityId: character.id,
                          entityName: character.name,
                      );
                    },
                  ),
                ),
              )
          ),
        )
    );
  }
}
