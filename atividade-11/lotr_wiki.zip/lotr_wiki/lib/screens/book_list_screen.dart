import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lotr_wiki/components/ListItem.dart';
import 'package:lotr_wiki/models/book.dart';
import 'package:http/http.dart' as http;

class BookListScreen extends StatefulWidget {
  const BookListScreen({Key? key}) : super(key: key);

  @override
  State<BookListScreen> createState() => _BookListScreenState();
}

class _BookListScreenState extends State<BookListScreen> {

  late List<Book> bookList = [];

  Future<void> getBooks() async {

    String? token = dotenv.env['TOKEN'];

    final response = await http
        .get(
        Uri.parse('https://the-one-api.dev/v2/book?limit=100'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        });

    if (response.statusCode != 200) {
      throw Exception('Failed to load characters');
    }

    List bookListJson = jsonDecode(response.body)['docs'] as List;

    List<Book> charactersLoaded = bookListJson.map((book) => Book.fromJson(book)).toList();

    setState(() {
      bookList = charactersLoaded;
    });

  }

  @override
  void initState() {
    getBooks();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
        ),
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/book_screen_background.jpg'),
                fit: BoxFit.cover
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(builder: (context, constraints) {
              if (bookList.isNotEmpty) {
                return ListView.separated(
                    itemBuilder: (BuildContext context, int index) {
                      Book book = bookList[index];
                      return ListItem(
                          detailScreenRouteName: "",
                          entityId: book.id,
                          entityName: book.name
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return const Divider(height: 0);
                    },
                    itemCount: bookList.length);
              } else {
                return const Center(
                    child: CircularProgressIndicator()
                );
              }
            }),
          ),
        )
    );
  }
}
