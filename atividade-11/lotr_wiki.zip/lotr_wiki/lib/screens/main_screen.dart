import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lotr_wiki/components/CardItem.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
              'assets/lotr_background.jpg',
            ),
            fit: BoxFit.cover
          )
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                CardItem(text: 'Livros', icon: Icons.book, onPressed: () {
                  Navigator.pushNamed(context, '/books');
                }),
                CardItem(text: 'Filmes', icon: Icons.local_movies, onPressed: () {
                  Navigator.pushNamed(context, '/movies');
                }),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                CardItem(text: 'Personagens', icon: Icons.person, onPressed: () {
                  Navigator.pushNamed(context, '/characters');
                }),
              ],
            )
          ],
        ),
      )
    );
  }
}