class Movie {
  late String id;
  late String name;
  late int runtimeInMinutes;
  late int budgetInMillions;
  late int rottenTomatoesScore;
  late String movieImage;

  Movie({
      required this.id,
      required this.name,
      required this.runtimeInMinutes,
      required this.budgetInMillions,
      required this.rottenTomatoesScore,
      required this.movieImage
  });

  factory Movie.fromJson(Map<String, dynamic> json) {
    Map _getMovieName(String name) {
      Map movieInfo = {
        "movieName": "",
        "movieImage": "",
      };

      switch (name) {
        case "The Unexpected Journey":
          movieInfo["movieName"] = "Uma Jornada Inesperada";
          movieInfo["movieImage"] = "assets/uma_jornada_inesperada.jpg";
          break;
        case "The Desolation of Smaug":
          movieInfo["movieName"] = "A Desolação de Smaug";
          movieInfo["movieImage"] = "assets/desolacao_de_smaug.jpg";
          break;
        case "The Battle of the Five Armies":
          movieInfo["movieName"] = "A Batalha dos Cinco Exércitos";
          movieInfo["movieImage"] = "assets/batalha_dos_cinco_exercitos.jpg";
          break;
        case "The Fellowship of the Ring":
          movieInfo["movieName"] = "A Sociedade do Anel";
          movieInfo["movieImage"] = "assets/a_sociedade_do_anel.jpg";
          break;
        case "The Two Towers ":
          movieInfo["movieName"] = "As Duas Torres";
          movieInfo["movieImage"] = "assets/as_duas_torres.jpg";
          break;
        case "The Return of the King":
          movieInfo["movieName"] = "O Retorno do Rei";
          movieInfo["movieImage"] = "assets/o_retorno_do_rei.jpg";
          break;
      }

      return movieInfo;
    }

    Map movieInfo = _getMovieName(json["name"]);

    return Movie(
      id: json['_id'],
      name: movieInfo["movieName"],
      runtimeInMinutes: json['runtimeInMinutes'],
      budgetInMillions: json['budgetInMillions'],
      rottenTomatoesScore: json['rottenTomatoesScore'],
      movieImage: movieInfo["movieImage"],
    );
  }


}