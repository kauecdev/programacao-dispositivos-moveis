class PageArguments {
  final String entityId;

  PageArguments(this.entityId);
}