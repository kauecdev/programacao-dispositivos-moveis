import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lotr_wiki/screens/book_list_screen.dart';
import 'package:lotr_wiki/screens/character_detail_screen.dart';
import 'package:lotr_wiki/models/page_arguments.dart';
import 'package:lotr_wiki/screens/character_list_screen.dart';
import 'package:lotr_wiki/screens/main_screen.dart';
import 'package:lotr_wiki/screens/movie_detail_screen.dart';
import 'package:lotr_wiki/screens/movie_list_screen.dart';

Future<void> main() async {
  await dotenv.load(fileName: ".env");
  runApp(const LotrWikiApp());
}

class LotrWikiApp extends StatelessWidget {
  const LotrWikiApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lotr Wiki',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const MainScreen(),
        '/books': (context) => const BookListScreen(),
        '/movies': (context) => const MovieListScreen(),
        '/characters': (context) => const CharacterListScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == CharacterDetailScreen.routeName) {
          final args = settings.arguments as PageArguments;

          return MaterialPageRoute(
            builder: (context) {
              return CharacterDetailScreen(
                characterId: args.entityId,
              );
            },
          );
        } else if (settings.name == MovieDetailScreen.routeName) {
          final args = settings.arguments as PageArguments;

          return MaterialPageRoute(
            builder: (context) {
              return MovieDetailScreen(
                movieId: args.entityId,
              );
            },
          );
        }
      },
    );
  }
}

