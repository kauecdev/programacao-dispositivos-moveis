package com.kauecavalcante.lotrwiki.lotr_wiki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
